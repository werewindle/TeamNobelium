﻿namespace HangmanGame
{
    using System;
    using System.Linq;

    class PlayHangman
    {
        static void Main()
        {
            GameEngine game = new GameEngine();
            game.Run();
        }
    }
}

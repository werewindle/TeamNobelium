﻿namespace HangmanGame
{
    using System;
    using System.Linq;

    public static class ConsoleRender
    {
        public static void PrintOnConsole(string inString)
        {
            Console.Write(inString);
        }
    }
}
